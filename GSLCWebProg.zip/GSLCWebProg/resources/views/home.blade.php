@extends('template')

@section('title', 'Home')

@section('content')
    <div>
        Ini adalah tampilan dari home

        @foreach ($productData as $item)
            <p>
                {{$item->name}}
            </p>
            <p>
                {{$item->price}}
            </p>
            <img src={{$item->image_url}}
        @endforeach
    </div>
@endsection
